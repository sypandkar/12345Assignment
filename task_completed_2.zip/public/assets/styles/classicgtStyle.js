const Styles = {
    containerImp: {
        padding: 30,
        boxSizing: 'border-box',
        marginBottom: "100px",
        background: "#CC0001",
        color: "white",
        borderRadius: 10,
    },
    heading: {
        color: "#F7F7F7",
        fontSize: 18,
    },
    containerText: {
        color: "#F7F7F7",
        fontSize: 16,
    }
}
export default Styles;