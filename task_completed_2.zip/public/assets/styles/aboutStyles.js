const Styles = {
    containerImp: {
        boxSizing: 'border-box',
        color: "Black",
        marginBottom: "50px",
        marginTop: "50px",
    },
    aboutHeading: {
        fontSize: "30px",
        fontWidth: "bolder",
        marginLeft: "100px",
    },
    subHeading: {
        marginTop: "-50px",
        marginLeft: "190px",
    },
};
export default Styles;