const MobileStyles = {
    containerImp: {
        padding: 30,
        boxSizing: 'border-box',
        marginBottom: "275px",
        background: "#CC0001",
        color: "white",
    },
    heading: {
        fontSize: 16,
        lineHeight: "35px",
    },
    containerText: {
        fontSize: 14,
    }
}
export default MobileStyles;